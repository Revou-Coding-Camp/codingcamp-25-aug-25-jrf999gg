// ===========================================
// Main Script: Welcome Message + Form Handling + Slider + Mobile Menu
// File: js/script.js
// ===========================================

document.addEventListener("DOMContentLoaded", function () {
  // ========================
  // 1. WELCOME MESSAGE: "Hi Name"
  // ========================
  const welcomeEl = document.getElementById("welcome");
  const nameSpan = document.getElementById("user-name");

  if (welcomeEl && nameSpan) {
    let userName = null;

    if (!userName) {
      userName = prompt("Hi! What’s your name?", "Hari") || "there";
      localStorage.setItem("userName", userName);
    }

    nameSpan.textContent = userName;
    welcomeEl.style.opacity = 1;
  }

  // ========================
  // 2. MESSAGE US FORM HANDLING
  // ========================
  const form = document.getElementById("messageForm");
  const output = document.getElementById("output");

  if (form && output) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const phone = document.getElementById("phone").value.trim();
      const message = document.getElementById("message").value.trim();

      // Validasi
      if (!name || !email || !phone || !message) {
        alert("⚠️ All fields are required!");
        return;
      }

      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        alert("📧 Please enter a valid email address.");
        return;
      }

      const phoneDigits = phone.replace(/\D/g, "");
      if (!/^\d{10,15}$/.test(phoneDigits)) {
        alert("📞 Please enter a valid phone number (10–15 digits).");
        return;
      }

      // Sanitasi input
      const sanitize = (str) => {
        const temp = document.createElement("div");
        temp.textContent = str;
        return temp.innerHTML;
      };

      // Format waktu
      const now = new Date();
      const formattedDate = now.toLocaleString("id-ID", {
        dateStyle: "full",
        timeStyle: "short",
      });

      // Tampilkan hasil
      output.innerHTML = `
        <strong>📅 Waktu Pengiriman:</strong> ${sanitize(formattedDate)}<br>
        <strong>👤 Nama:</strong> ${sanitize(name)}<br>
        <strong>✉️ Email:</strong> ${sanitize(email)}<br>
        <strong>📞 Telepon:</strong> ${sanitize(phone)}<br>
        <strong>💬 Pesan:</strong> ${sanitize(message)}
      `;

      form.reset();
      output.style.display = "block";
      output.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  // ========================
  // 3. AUTO SLIDING BANNER + LOOP + ARROWS + DOTS
  // ========================
  const slides = document.querySelectorAll(".slide");
  const dots = document.querySelectorAll(".dot");
  const slider = document.querySelector(".slider");
  const prevBtn = document.querySelector(".slider-btn.prev");
  const nextBtn = document.querySelector(".slider-btn.next");
  const sliderContainer = document.querySelector(".slider-container");

  const totalSlides = slides.length;

  if (slider && totalSlides > 0) {
    let currentSlide = 0;
    let slideInterval;

    function goToSlide(index) {
      if (index >= totalSlides) currentSlide = 0;
      else if (index < 0) currentSlide = totalSlides - 1;
      else currentSlide = index;

      slider.style.transform = `translateX(-${currentSlide * 100}%)`;
      dots.forEach((dot, i) => {
        dot.classList.toggle("active", i === currentSlide);
      });
    }

    function nextSlide() {
      goToSlide(currentSlide + 1);
    }

    function prevSlide() {
      goToSlide(currentSlide - 1);
    }

    function startAutoSlide() {
      slideInterval = setInterval(nextSlide, 4000);
    }

    function resetAutoSlide() {
      clearInterval(slideInterval);
      startAutoSlide();
    }

    if (sliderContainer) {
      sliderContainer.addEventListener("mouseenter", () => clearInterval(slideInterval));
      sliderContainer.addEventListener("mouseleave", startAutoSlide);
    }

    if (prevBtn) {
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        prevSlide();
        resetAutoSlide();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        nextSlide();
        resetAutoSlide();
      });
    }

    dots.forEach((dot) => {
      dot.addEventListener("click", () => {
        const index = parseInt(dot.getAttribute("data-index"));
        goToSlide(index);
        resetAutoSlide();
      });
    });

    // Inisialisasi
    goToSlide(0);
    startAutoSlide();
  }

  // ========================
  // 4. MOBILE MENU TOGGLE
  // ========================
  const hamburger = document.querySelector(".hamburger");
  const navLinks = document.querySelector(".nav-links");

  if (hamburger && navLinks) {
    hamburger.addEventListener("click", () => {
      navLinks.classList.toggle("active");
      hamburger.classList.toggle("active");
    });

    document.querySelectorAll(".nav-links a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("active");
        hamburger.classList.remove("active");
      });
    });
  }

  // ========================
  // 5. ANIMASI TIMELINE SAAT SCROLL
  // ========================
  const timelineItems = document.querySelectorAll(".timeline-item");

  function checkTimelineVisibility() {
    timelineItems.forEach((item) => {
      const rect = item.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.8) {
        item.classList.add("visible");
      }
    });
  }

  window.addEventListener("load", checkTimelineVisibility);
  window.addEventListener("scroll", checkTimelineVisibility);
});